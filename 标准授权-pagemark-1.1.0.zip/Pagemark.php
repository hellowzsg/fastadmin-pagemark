<?php

namespace addons\pagemark;

use think\Addons;

/**
 * 插件
 */
class Pagemark extends Addons
{

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        return true;
    }

    /**
     * 插件启用方法
     * @return bool
     */
    public function enable()
    {
        return true;
    }

    /**
     * 插件禁用方法
     * @return bool
     */
    public function disable()
    {
        return true;
    }

    public function configInit(&$params)
    {

        $getUserInfo = function () {
            // 尝试获取前台auth
            $auth  = \app\common\library\Auth::instance();
            if ($auth->getUser()) {
                return $auth->getUser();
            }

            // 获取后台auth
            $auth = \app\admin\library\Auth::instance();
            if ($auth) {
                $userinfo = model('app\admin\model\Admin')->find($auth->id);
                if ($userinfo) {
                    // admin没有手机号
                    $userinfo->mobile = '';
                    return $userinfo;
                }
            }
            return null;
        };
        $pagemark = [];
        $userinfo = $getUserInfo();
        $pagemark['userinfo'] = $userinfo ? [
            'username'  => $userinfo->username,
            'nickname'  => $userinfo->nickname,
            'mobile'    => $userinfo->mobile,
            'email'     => $userinfo->email
        ]: [];
        $fullconfig = get_addon_fullconfig('pagemark');
        $config = [];
        foreach ($fullconfig as $item) {
            $v = $item['value'];
            $type = $item['type'];
            if ($type == 'tip') {
                continue;
            }
            if (in_array($type, ['checkbox', 'checkbox'])) {
                $v = explode(',', $v);
            }
            $config[$item['name']] = [
                'value' => $v,
                'type'  => $type
            ];
        }
        $pagemark['config'] = $config;

        $params['pagemark'] = $pagemark;
    }
}
