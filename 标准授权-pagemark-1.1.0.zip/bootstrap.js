require.config({
    paths: {'watermark-dom': '../addons/pagemark/js/watermark',}
});

require(['watermark-dom'], function (watermark) {
    var config = Config.pagemark.config;
    var userinfo = Config.pagemark.userinfo;
    if (config.mark_area==undefined || config.mark_area.value.indexOf('close')!=-1) {
        return ;
    }
    // 后台
    if (config.mark_area.value.indexOf('backend')!=-1 && Config.controllername == 'index' && Config.actionname == 'index') {
        var setting = getWaterMarkSetting(config, userinfo);
        markWorking(watermark, setting, config);
    }
    // user
    if (config.mark_area.value.indexOf('user')!=-1 && Config.controllername == 'user') {
        var setting = getWaterMarkSetting(config, userinfo);
        markWorking(watermark, setting, config);
    }

    function markWorking(wm, setting, config) {
        wm.init(setting);
        // 是否开启动态水印
        if (config.dmc_mark!=undefined && config.dmc_mark['value']=='1') {
            // 时间间隔
            var dmc_time = (config.dmc_time!=undefined && config.dmc_time['value']>0) ? Number(config.dmc_time['value']) : 5;
            setInterval(function () {
                // 是否开启时间戳水印
                var txt = (config.timestamp_mark!=undefined && config.timestamp_mark['value']=='1') ? (setting.watermark_txt + ' ' +(new Date().getTime())) : setting.watermark_txt;
                wm.load({watermark_txt: txt});
            }, 1000 * dmc_time);
        }
    }
    function getWaterMarkSetting(config, userinfo) {
        var watermarksetting = {
            watermark_id: 'wm_div_id',          //水印总体的id
            watermark_prefix: 'mask_div_id',    //小水印的id前缀
            watermark_txt:"测试水印",      //水印的内容
            watermark_x:20,                     //水印起始位置x轴坐标
            watermark_y:20,                     //水印起始位置Y轴坐标
            watermark_rows:0,                   //水印行数
            watermark_cols:0,                   //水印列数
            watermark_x_space:50,              //水印x轴间隔
            watermark_y_space:50,               //水印y轴间隔
            watermark_font:'楷体',           //水印字体
            watermark_color:'black',            //水印字体颜色
            watermark_fontsize:'17px',          //水印字体大小
            watermark_alpha:0.16,               //水印透明度，要求设置在大于等于0.005
            watermark_width:250,                //水印宽度
            watermark_height:100,               //水印长度
            watermark_angle:15,                 //水印倾斜度数
            watermark_parent_width:0,      //水印的总体宽度（默认值：body的scrollWidth和clientWidth的较大值）
            watermark_parent_height:0,     //水印的总体高度（默认值：body的scrollHeight和clientHeight的较大值）
            watermark_parent_node:null,     //水印插件挂载的父元素element,不输入则默认挂在body上
            monitor:true,                   //monitor 是否监控， true: 不可删除水印; false: 可删水印。
        };
        // 水印内容
        var watermark_txt = [];
        if (config.text.value.indexOf('username')!=-1 && userinfo.username!=undefined && userinfo.username.length>0) {
            watermark_txt.push(userinfo.username);
        }
        if (config.text.value.indexOf('nickname')!=-1 && userinfo.nickname!=undefined && userinfo.nickname.length>0) {
            watermark_txt.push(userinfo.nickname);
        }
        if (config.text.value.indexOf('email')!=-1 && userinfo.email!=undefined && userinfo.email.length>0) {
            watermark_txt.push(userinfo.email);
        }
        if (config.text.value.indexOf('mobile')!=-1 && userinfo.mobile!=undefined && userinfo.mobile.length>0) {
            watermark_txt.push(userinfo.mobile);
        }
        if (config.text.value.indexOf('append')!=-1 && config.cstmd_text['value'].length>0) {
            watermark_txt.push(config.cstmd_text['value']);
        }
        watermarksetting.watermark_txt = watermark_txt.join(" ");

        // 其他设置
        var list = ['x','y','rows','cols','x_space','y_space','color','font','width','height','angle','fontsize','alpha'];
        list.forEach(function (k){
            if (config[k]!=undefined && config[k]['value'].length>0) {
                var settingKey =  'watermark_' + k;
                if (config[k]['type'] == 'number') {
                    config[k]['value'] = Number(config[k]['value']);
                }
                watermarksetting[settingKey] = config[k]['value'];
            }
        });
        return watermarksetting;
    }
});
